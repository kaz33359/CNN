jQuery(document).ready(function () { 
	'use strict'; // use strict mode
	
	// twitter plugin
    $('#tweecool').tweecool({
        //settings
        username: 'envato',
        limit: 1
    });
});